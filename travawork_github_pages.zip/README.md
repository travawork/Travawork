# Travawork

Website Travawork — Travel, Academy, Career.

## Current status
- Travel: Coming Soon
- Academy: Basic / Pro / Premium
- Payment: frontend placeholder
- Login & Dashboard: frontend placeholder

## GitHub Pages
Set GitHub Pages source to the `main` branch and `/ (root)`.
