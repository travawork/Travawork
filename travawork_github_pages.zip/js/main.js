// Travawork frontend JavaScript — ready for future interactive features.
